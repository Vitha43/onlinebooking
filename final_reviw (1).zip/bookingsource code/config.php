<?php
session_start();
$dbHost = 'localhost';
$dbName = 'userdata';
$dbUsername = 'root';
$dbPassword = '';
$dbc= mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

?>
