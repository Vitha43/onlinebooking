
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="style.css">

<section class ="my-5">
    <div class="py-5">
        <h2 class="text-center">OUR SERVICES</h2>
    </div>
    <div class="container-fluid">
        <div class ="row">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="card" >
  <img class="card-img-top" src="images/cc5.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">ur choice:)</h4>
    <p class="card-text">for RIDERS</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
            </div>

              <div class="col-lg-6 col-md-6 col-12">
                <div class="card" >
  <img class="card-img-top" src="images/cc6.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">ur choice:)</h4>
    <p class="card-text">for MINGLERS</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
            </div>

              <div class="col-lg-6 col-md-6 col-12">
                <div class="card" >
  <img class="card-img-top" src="images/cc7.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">ur choice:)</h4>
    <p class="card-text">TRAVELLERS.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
            </div>

              <div class="col-lg-6 col-md-6 col-12">
                <div class="card" >
  <img class="card-img-top" src="images/cc8.jpg" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">ur choice:)</h4>
    <p class="card-text">PERFECTION</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
    </div>
        </div>
    </div>
    </section>
    <footer>
        <p class="p-3 bg-dark text-white text-center"> @call_me_ra_0ne</p>
    </footer>
